const pop = document.querySelector('.pop')
pop.addEventListener('click', ()=>{
    const erikiNav = document.querySelector('.eriki-nla-nav')
    erikiNav.classList.toggle('nav-show')
})