const pop = document.querySelector('.pop')
pop.addEventListener('click', ()=>{
    const owuNav = document.querySelector('.owu-nav')
    owuNav.classList.toggle('nav-show')
})