const pop = document.querySelector('.pop')
pop.addEventListener('click', ()=>{
    const oyegunleNav = document.querySelector('.oyegunle-nav')
    oyegunleNav.classList.toggle('nav-show')
})