const pop = document.querySelector('.pop')
pop.addEventListener('click', ()=>{
    const akogunNav = document.querySelector('.akogun-nav')
    akogunNav.classList.toggle('nav-show')
})