const pop = document.querySelector('.pop')
pop.addEventListener('click', ()=>{
    const ishokoNav = document.querySelector('.ishoko-nav')
    ishokoNav.classList.toggle('nav-show')
})